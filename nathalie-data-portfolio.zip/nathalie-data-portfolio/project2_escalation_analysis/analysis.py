"""Project 2: Escalation Pattern Analysis
Run this script after placing your dataset in data/escalations.csv
"""

import pandas as pd
import matplotlib.pyplot as plt

# 1) Load dataset
df = pd.read_csv("data/escalations.csv")

# 2) Parse dates and compute resolution time
df["opened_date"] = pd.to_datetime(df["opened_date"])
df["resolved_date"] = pd.to_datetime(df["resolved_date"])
df["days_to_resolve"] = (df["resolved_date"] - df["opened_date"]).dt.days

print("HEAD:")
print(df.head())

# 3) Patterns
print("\nCase types:")
print(df["case_type"].value_counts())

print("\nAvg days to resolve by department:")
print(df.groupby("department_involved")["days_to_resolve"].mean().sort_values(ascending=False))

# 4) Visualize
plt.figure()
df.groupby("case_type")["days_to_resolve"].mean().sort_values().plot(kind="barh")
plt.title("Avg Resolution Days by Case Type")
plt.xlabel("Days")
plt.ylabel("Case Type")
plt.show()
