# Project 2 — Escalation Pattern Analysis (Python)

**Goal:** Find bottlenecks and trends in escalations and propose improvements.

## Dataset
- `data/escalations.csv` (synthetic sample included)
- Columns: case_id, case_type, department_involved, opened_date, resolved_date, outcome

## Approach
1. Load and compute days-to-resolve
2. Identify slow case categories / departments
3. Visualize turnaround time
4. Write recommendations

## Recommendations
Add 3 bullets after analysis.
