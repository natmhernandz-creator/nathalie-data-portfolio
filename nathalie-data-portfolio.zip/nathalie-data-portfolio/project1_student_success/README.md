# Project 1 — Student Success Insights (Python)

**Goal:** Demonstrate data cleaning, exploratory data analysis (EDA), and visualization in Python.

## Problem
Explore student success patterns like GPA, attendance, and retention by program/modality.

## Dataset
- `data/students.csv` (synthetic sample included)
- Columns: StudentID, Program, Modality, AttendanceRate, GPA, CreditsAttempted, CreditsCompleted, Term, Retained

## Approach
1. Load and inspect
2. Clean duplicates / missing values
3. Answer core questions
4. Visualize findings

## Key Findings
Add 3–5 bullets after you run your analysis.

## Next Steps
Add deeper analysis (risk flags, correlations, etc.).
