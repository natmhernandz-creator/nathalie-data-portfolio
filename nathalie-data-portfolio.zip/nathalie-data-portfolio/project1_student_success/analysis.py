"""Project 1: Student Success Insights
Run this script after placing your dataset in data/students.csv
"""

import pandas as pd
import matplotlib.pyplot as plt

# 1) Load dataset
df = pd.read_csv("data/students.csv")

# 2) Quick look
print("HEAD:")
print(df.head())
print("\nINFO:")
print(df.info())

# 3) Basic cleaning
df = df.drop_duplicates()
# Convert GPA to numeric; coerce errors to NaN then fill with median
df["GPA"] = pd.to_numeric(df["GPA"], errors="coerce")
df["GPA"] = df["GPA"].fillna(df["GPA"].median())

# 4) Simple EDA questions
print("\nAverage GPA by Program:")
print(df.groupby("Program")["GPA"].mean().sort_values(ascending=False))

print("\nAverage Attendance by Program:")
print(df.groupby("Program")["AttendanceRate"].mean().sort_values(ascending=False))

# 5) Visualizations
plt.figure()
df["GPA"].hist()
plt.title("GPA Distribution")
plt.xlabel("GPA")
plt.ylabel("Count")
plt.show()

plt.figure()
df["Program"].value_counts().plot(kind="bar")
plt.title("Students by Program")
plt.xlabel("Program")
plt.ylabel("Count")
plt.show()
