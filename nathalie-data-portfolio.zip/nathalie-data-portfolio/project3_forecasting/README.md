# Project 3 — Simple Trend Forecasting (Python)

**Goal:** Show basic time-series thinking without claiming advanced ML.

## Dataset
- `data/enrollments.csv` (synthetic sample included)
- Columns: date, enrollments

## Approach
1. Aggregate by month
2. Plot time trend
3. Compute rolling average as a simple forecast proxy
