"""Project 3: Simple Trend Forecasting (Python)
Run this script after placing your dataset in data/enrollments.csv
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/enrollments.csv")
df["date"] = pd.to_datetime(df["date"])

# Aggregate monthly counts
monthly = df.groupby(df["date"].dt.to_period("M"))["enrollments"].sum()
monthly.index = monthly.index.to_timestamp()

print(monthly.head())

# Plot actual trend
plt.figure()
plt.plot(monthly, label="Actual")
plt.title("Monthly Enrollments Over Time")
plt.xlabel("Month")
plt.ylabel("Enrollments")
plt.legend()
plt.show()

# Simple 3-month rolling average
rolling = monthly.rolling(3).mean()

plt.figure()
plt.plot(monthly, label="Actual")
plt.plot(rolling, label="3-mo Rolling Avg")
plt.title("Simple Forecast (Rolling Average)")
plt.xlabel("Month")
plt.ylabel("Enrollments")
plt.legend()
plt.show()
