# Nathalie Hernandez — Python Data Portfolio

This portfolio contains three Python projects that demonstrate foundational data science skills:
1. **Student Success Insights** — data cleaning, EDA, and visualization
2. **Escalation Pattern Analysis** — operational analytics and recommendations
3. **Simple Forecasting** — time trends and rolling-average forecasting

Each project has:
- `analysis.py` (run in PyCharm)
- `data/` folder with a sample CSV
- `README.md` explaining the problem and approach

## How to run
1. Open the repo in PyCharm CE
2. Create/activate a venv (optional)
3. Install packages:
   `pip install pandas numpy matplotlib`
4. Open a project folder and run `analysis.py`
